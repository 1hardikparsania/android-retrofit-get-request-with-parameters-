package com.example.parsaniahardik.retrofitgetparameter;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

public interface GetInterface {

    String JSONGETURL = "https://demonuts.com/Demonuts/JsonTest/Tennis/";

    @GET("loginGETrequest.php")
    Call<String> getUserLogin( @QueryMap Map<String, String> options);
}
